[![librtlsdr version](https://img.shields.io/github/tag/librtlsdr/librtlsdr.svg?style=flat&label=librtlsdr)](https://github.com/librtlsdr/librtlsdr/releases)
[![Build Status](http://circleci-badges-max.herokuapp.com/img/librtlsdr/librtlsdr/master?token=:circle-ci-token)](https://circleci.com/gh/librtlsdr/librtlsdr/tree/master)
[![GPLv2 License](http://img.shields.io/badge/license-GPLv2-brightgreen.svg)](https://tldrlegal.com/license/gnu-general-public-license-v2)

# Description

rtl-sdr turns your Realtek RTL2832 based DVB dongle into a SDR receiver


# For more information see:

http://sdr.osmocom.org/trac/wiki/rtl-sdr
